﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoesOnline.Const
{
    public class ConstValue
    {
        public static string ConnectString = @"Data Source=WILLIAM\PERFECT;Initial catalog=ShoesOnlineDB;Integrated Security=True";
    }
}
