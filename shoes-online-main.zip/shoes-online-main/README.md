# Cửa hàng giày online
## Mô tả
* Trang web bán giày cho phép mọi người tham gia mua và bán giày thông qua nền tảng online
* Trang web sử dụng HTML, CSS, JS và Boostrap 5 cho phần Frontend và C#, SQLServer cho phần Backend
## Vai trò
* Customer - người dùng hay người mua hàng
* Seller - nhà cung cấp hoặc người bán hàng
* Admin - Quản trị viên hệ thống
## Lệnh git
Tên branch: main Thắng Trang Duy 
* Mới bắt đầu chưa tải project về tạo một thư mục chứa code
  * **git clone url** (lệnh tải project ở branch main về máy)
  * **cd tên_thư_mục_code** (lệnh nhảy vào thư mục code)
  * **git checkout tên_branch** (lệnh này để chuyển branch tùy ý)
  * **git pull origin tên_branch** (lệnh này lấy project ở các branch tùy ý)
* Những lần sau (đã tải project) pull code về máy
  * **cd tên_thư_mục_code**
  * **git pull origin tên_branch**
* Lệnh push code lên branch
  * **git add .**
  * **git commit -m 'Nội dung đã chỉnh sửa gì'**
  * **git push origin tên_branch**
## Lưu ý
* File database nằm trong thư mục code
## Note
https://docs.google.com/document/d/17XDecdNIuN1e6QT3bQijfLQHM3CVpPDKGkAJZ4j8NAs/edit#heading=h.5e6p36r4bl3o
